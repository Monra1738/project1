package com.example.comuvicad201911rvilardell;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.comuvicad201911rvilardell.Entities.Anime;
import com.example.comuvicad201911rvilardell.Singelton.Singleton;

public class VistaAmpliada extends AppCompatActivity {

    private int elementPosition;
    private Anime animes;

    private EditText name;
    private EditText autor;
    private EditText capitols;
    private EditText sessions;
    private EditText charecterPrincipal;
    private CheckBox state;
    private EditText description;
    private EditText studios;
    private EditText source;
    private EditText premiered;
    private EditText licensors;
    private EditText name_Japanes;

    private String type;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vista_ampliada);

        Toast.makeText(super.getApplicationContext(), "Mode vista ampliada", Toast.LENGTH_SHORT).show();
        Bundle extras = getIntent().getExtras();

        if (extras != null) {

            elementPosition = extras.getInt("position");

        }
        //Log.i("log",Integer.toString(elementPosition));
        animes = Singleton.getInstance().getIndex(elementPosition);

        state = findViewById(R.id.state);
        name = findViewById(R.id.name);
        autor = findViewById(R.id.autor);
        capitols = findViewById(R.id.capitols);
        sessions = findViewById(R.id.sessions);
        charecterPrincipal = findViewById(R.id.charecterPrincipal);
        description = findViewById(R.id.description);
        studios = findViewById(R.id.studios);
        source = findViewById(R.id.sources);
        premiered = findViewById(R.id.premiered);
        licensors = findViewById(R.id.licensors);
        name_Japanes = findViewById(R.id.name_Japanes);


        state.setChecked(animes.getState());
        name.setText(animes.getNom());
        autor.setText(animes.getAutor());
        capitols.setText(Integer.toString(animes.getCapitols()));
        sessions.setText(Integer.toString(animes.getSessions()));
        charecterPrincipal.setText(animes.getCharecterPrincipal());
        description.setText(animes.getDescription());
        studios.setText(animes.getStudios());
        source.setText(animes.getSource());
        premiered.setText(animes.getPremiered());
        licensors.setText(animes.getLicensors());
        name_Japanes.setText(animes.getName_Japanes());

        state.setEnabled(false);
        name.setEnabled(false);
        autor.setEnabled(false);
        capitols.setEnabled(false);
        sessions.setEnabled(false);
        charecterPrincipal.setEnabled(false);
        description.setEnabled(false);
        studios.setEnabled(false);
        source.setEnabled(false);
        premiered.setEnabled(false);
        licensors.setEnabled(false);
        name_Japanes.setEnabled(false);


    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.bar_ampliat, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.editIcon) {
            Toast.makeText(super.getApplicationContext(), "Ja pots editar!", Toast.LENGTH_SHORT).show();

            state.setEnabled(true);
            name.setEnabled(true);
            autor.setEnabled(true);
            capitols.setEnabled(true);
            sessions.setEnabled(true);
            charecterPrincipal.setEnabled(true);
            description.setEnabled(true);
            studios.setEnabled(true);
            source.setEnabled(true);
            premiered.setEnabled(true);
            licensors.setEnabled(true);
            name_Japanes.setEnabled(true);



            return true;
        }
        if (id == R.id.saveIcon) {
            Toast.makeText(super.getApplicationContext(),"Canvis guardat correctament",Toast.LENGTH_SHORT).show();

            animes.setNom(name.getText().toString());

            animes.setAutor( autor.getText().toString());
            try{
                animes.setCapitols(Integer.parseInt(capitols.getText().toString()));

            }
            catch (Exception e){
                animes.setCapitols(0);
            }
            try{
                animes.setSessions(Integer.parseInt(sessions.getText().toString()));

            }
            catch (Exception e){
                animes.setSessions(0);
            }
            if(state.isChecked())animes.setState(true);
            else animes.setState( false);

            animes.setCharecterPrincipal(charecterPrincipal.getText().toString());
            animes.setDescription(description.getText().toString());
            animes.setSource(source.getText().toString());
            animes.setStudios(studios.getText().toString());
            animes.setPremiered(premiered.getText().toString());
            animes.setLicensors(licensors.getText().toString());
            animes.setName_Japanes(name_Japanes.getText().toString());


            Singleton.getInstance().updateAnime(animes,elementPosition);
            Intent data = new Intent();
            type="Save";
            data.putExtra("action",type);
            data.putExtra("position",elementPosition);
            setResult(RESULT_OK, data);
            finish();
            return true;

        }
        if(id==R.id.deleteIcon){
            AlertDialog.Builder builder= new AlertDialog.Builder(VistaAmpliada.this);

            //definir les caracteristiques del nostre dialog

            builder.setMessage("SEGUR QUE VOLS ELIMINAR EN "+name.getText().toString()+"?");
            builder.setTitle("Borrar");

            //Afegir Buttons
            builder.setPositiveButton("Acceptar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    Toast.makeText(getApplicationContext(),"Persona eliminada correctament",Toast.LENGTH_SHORT).show();
                    //COM ELIMINEM??
                    type="Remove";
                    Singleton.getInstance().deleteAnime(elementPosition);
                    Intent data = new Intent();
                    data.putExtra("action",type);
                    data.putExtra("position",elementPosition);
                    setResult(RESULT_OK, data);
                    finish();
                }
            });
            builder.setNegativeButton("Cancel·lar", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int id) {
                    return;
                }
            });
            //crearem la finestra de diàleg
            AlertDialog dialeg=builder.create();
            //mostra el dialeg
            dialeg.show();
            return true;
        } else
            return super.onOptionsItemSelected(item);

    }
}
package com.example.comuvicad201911rvilardell;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;

import com.example.comuvicad201911rvilardell.Entities.Anime;
import com.example.comuvicad201911rvilardell.Singelton.Singleton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rv_list;
    private ArrayList<Anime> anime;
    private Adapter_Anime adapter;
    private int LOOK_REQUEST_CODE = 12;
    private int ADD_REQUEST_CODE = 100;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Singleton.getInstance().populate();
        anime = Singleton.getInstance().getAnimes();

        rv_list = findViewById(R.id.rv_list);

        LinearLayoutManager ll_manager = new LinearLayoutManager(this);
        rv_list.setLayoutManager(ll_manager);


        this.adapter = new Adapter_Anime(anime, this, LOOK_REQUEST_CODE);
        rv_list.setAdapter(adapter);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.add_bar, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.addanime) {
            Intent i = new Intent(MainActivity.this, AddActivity.class);
            startActivityForResult(i, ADD_REQUEST_CODE);
            return true;
        } else
            return super.onOptionsItemSelected(item);
    }

    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && requestCode == ADD_REQUEST_CODE) {
            adapter.notifyItemInserted(adapter.getItemCount() - 1);
            anime = Singleton.getInstance().getAnimes();

        }

        if (resultCode == RESULT_OK && requestCode == LOOK_REQUEST_CODE) {


            if (data.getExtras().getString("action").equals("Save")) {
                adapter.notifyItemChanged(data.getExtras().getInt("position"));
                anime = Singleton.getInstance().getAnimes();
            } else {
                adapter.notifyDataSetChanged();
                anime = Singleton.getInstance().getAnimes();

            }


        }

    }
}
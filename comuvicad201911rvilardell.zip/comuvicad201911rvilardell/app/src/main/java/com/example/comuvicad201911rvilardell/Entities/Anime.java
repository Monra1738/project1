package com.example.comuvicad201911rvilardell.Entities;

public class Anime {
    private String Nom;
    private String Autor;
    private int Capitols;
    private int Sessions;
    private String CharecterPrincipal;
    private Boolean State;
    private  String Description;
    private  String Studios;
    private  String Source;
    private  String Premiered;
    private String Licensors;
    private  String Name_Japanes;

    public Anime(String nom, String autor, int capitols, int sessions, String charecterPrincipal, Boolean state, String description, String studios, String source, String premiered, String licensors, String name_Japanes) {
        Nom = nom;
        Autor = autor;
        Capitols = capitols;
        Sessions = sessions;
        CharecterPrincipal = charecterPrincipal;
        State = state;
        Description = description;
        Studios = studios;
        Source = source;
        Premiered = premiered;
        Licensors = licensors;
        Name_Japanes = name_Japanes;
    }

    public Anime() {
    }

    public String getNom() {
        return Nom;
    }

    public void setNom(String nom) {
        Nom = nom;
    }

    public String getAutor() {
        return Autor;
    }

    public void setAutor(String autor) {
        Autor = autor;
    }

    public int getCapitols() {
        return Capitols;
    }

    public void setCapitols(int capitols) {
        Capitols = capitols;
    }

    public int getSessions() {
        return Sessions;
    }

    public void setSessions(int sessions) {
        Sessions = sessions;
    }

    public String getCharecterPrincipal() {
        return CharecterPrincipal;
    }

    public void setCharecterPrincipal(String charecterPrincipal) {
        CharecterPrincipal = charecterPrincipal;
    }

    public Boolean getState() {
        return State;
    }

    public void setState(Boolean state) {
        State = state;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String description) {
        Description = description;
    }

    public String getStudios() {
        return Studios;
    }

    public void setStudios(String studios) {
        Studios = studios;
    }

    public String getSource() {
        return Source;
    }

    public void setSource(String source) {
        Source = source;
    }

    public String getPremiered() {
        return Premiered;
    }

    public void setPremiered(String premiered) {
        Premiered = premiered;
    }

    public String getLicensors() {
        return Licensors;
    }

    public void setLicensors(String licensors) {
        Licensors = licensors;
    }

    public String getName_Japanes() {
        return Name_Japanes;
    }

    public void setName_Japanes(String name_Japanes) {
        Name_Japanes = name_Japanes;
    }


    @Override
    public String toString() {
        return "Anime{" +
                "Nom='" + Nom + '\'' +
                ", Autor='" + Autor + '\'' +
                ", Capitols=" + Capitols +
                ", Sessions=" + Sessions +
                ", CharecterPrincipal='" + CharecterPrincipal + '\'' +
                ", State=" + State +
                ", Description='" + Description + '\'' +
                ", Studios='" + Studios + '\'' +
                ", Source='" + Source + '\'' +
                ", Premiered='" + Premiered + '\'' +
                ", Licensors='" + Licensors + '\'' +
                ", Name_Japanes='" + Name_Japanes + '\'' +
                '}';
    }
}


package com.example.comuvicad201911rvilardell.Singelton;
import com.example.comuvicad201911rvilardell.Entities.Anime;

import java.util.ArrayList;
import java.util.List;

public class Singleton {
    private static final Singleton ourInstance = new Singleton();

    private ArrayList<Anime> animes;
    public static Singleton getInstance() {
        return ourInstance;
    }

    private Singleton() {

        this.animes= new ArrayList<Anime>();
    }

    public ArrayList<Anime> getAnimes() {

        return animes;
    }
    public Anime getIndex(int index){

        return animes.get(index);

    }
    public void  updateAnime(Anime anime,int index){

        animes.set(index,anime);
    }
    public void AddAnime(Anime anime){

        animes.add(anime);

    }
    public void deleteAnime(int index){
        animes.remove(index);
    }
    public void populate(){
        animes.add(new Anime("One Piece", "Oda-sense",900,1,"Luffy",true,"Pirates i aventures","Toei animation","Toei Animation2.0","summer199","jnk","Japanes"));
        animes.add(new Anime("Kimetsu no Yaiba", "Oda-sense",24,1,"Luffy",false,"Pirates i aventures","Toei animation","Toei Animation2.0","summer199","jnk","Japanes"));
        animes.add(new Anime("karakai Jozu no Takagi-san", "Oda-sense",24,2,"Nisykata & Takagi-san",true,"Pirates i aventures","Toei animation","Toei Animation2.0","summer199","jnk","Japanes"));
        animes.add(new Anime("Ao no Flag", "Oda-sense",0,0,"----",false,"Pirates i aventures","Toei animation","Toei Animation2.0","summer199","jnk","Japanes"));
        animes.add(new Anime("Bokutachi wa", "Oda-sense",14,2,"Naryuki",true,"Pirates i aventures","Toei animation","Toei Animation2.0","summer199","jnk","Japanes"));
        animes.add(new Anime("Ore w", "Oda-sense",12,1,"Panji",true,"Pirates i aventures","Toei animation","Toei Animation2.0","summer199","jnk","Japanes"));

    }
}

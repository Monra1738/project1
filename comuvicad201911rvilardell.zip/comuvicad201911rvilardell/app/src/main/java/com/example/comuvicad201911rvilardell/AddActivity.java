package com.example.comuvicad201911rvilardell;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.comuvicad201911rvilardell.Entities.Anime;
import com.example.comuvicad201911rvilardell.Singelton.Singleton;

public class AddActivity extends AppCompatActivity {

    private Anime myanime;

    private EditText name;
    private EditText autor;
    private EditText capitols;
    private EditText sessions;
    private EditText charecterPrincipal;
    private CheckBox state;
    private EditText description;
    private EditText studios;
    private EditText source;
    private EditText premiered;
    private EditText licensors;
    private EditText name_Japanes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        Toast.makeText(super.getApplicationContext(), "Et disposes a afegir una nou anime!!!", Toast.LENGTH_SHORT).show();
        state = findViewById(R.id.state);
        name = findViewById(R.id.name);
        autor = findViewById(R.id.autor);
        capitols = findViewById(R.id.capitols);
        sessions = findViewById(R.id.sessions);
        charecterPrincipal = findViewById(R.id.charecterPrincipal);
        state = findViewById(R.id.state);
        description = findViewById(R.id.description);
        studios = findViewById(R.id.studios);
        source = findViewById(R.id.sources);
        premiered = findViewById(R.id.premiered);
        licensors = findViewById(R.id.licensors);
        name_Japanes = findViewById(R.id.name_Japanes);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.formulari_bar, menu);
        return true;
    }


    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.save) {

            Toast.makeText(super.getApplicationContext(), "Anime afeguit correctament!!", Toast.LENGTH_SHORT).show();
            myanime = new Anime();


            myanime.setNom(name.getText().toString());

            myanime.setAutor(autor.getText().toString());
            try {
                myanime.setCapitols(Integer.parseInt(capitols.getText().toString()));

            } catch (Exception e) {
                myanime.setCapitols(0);
            }
            try {
                myanime.setSessions(Integer.parseInt(sessions.getText().toString()));

            } catch (Exception e) {
                myanime.setSessions(0);
            }
            if (state.isChecked()) myanime.setState(true);
            else myanime.setState(false);

            myanime.setCharecterPrincipal(charecterPrincipal.getText().toString());
            myanime.setDescription(description.getText().toString());
            myanime.setSource(source.getText().toString());
            myanime.setStudios(studios.getText().toString());
            myanime.setPremiered(premiered.getText().toString());
            myanime.setLicensors(licensors.getText().toString());
            myanime.setName_Japanes(name_Japanes.getText().toString());

            Singleton.getInstance().AddAnime(myanime);
            Intent data = new Intent();
            setResult(RESULT_OK, data);
            finish();


            return true;
        }
        if (id == R.id.delete) {
            //Fem un toast per avisar al usuari que ha netejat els camps del formulari
            Toast.makeText(super.getApplicationContext(), "Camps netejats correctament!!", Toast.LENGTH_SHORT).show();

            state.setChecked(false);
            name.setText("");
            autor.setText("");
            source.setText("");
            capitols.setText("");
            premiered.setText("");
            sessions.setText("");
            charecterPrincipal.setText("");
            description.setText("");
            studios.setText("");
            licensors.setText("");
            name_Japanes.setText("");
            return true;
        } else {
            return super.onOptionsItemSelected(item);
        }

    }
}
